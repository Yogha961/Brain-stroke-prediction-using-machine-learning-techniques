from django.shortcuts import render, redirect

# Create your views here.
from flask import render_template

from patient.models import RegisterModel, brainstrokeModel
import pickle
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()

model = pickle.load(open("model_pickle.pkl", 'rb'))

def home(request):
    return render(request, 'home.html')

def index(request):
    if request.method == "POST":
        name = request.POST.get('userid')
        password = request.POST.get('password')
        try:
            enter = RegisterModel.objects.get(userid=name,password=password)
            request.session["names"]= enter.id
            return redirect('mydetails')
        except:
            pass

    return render(request, 'index.html')

def register(request):

    if request.method == "POST":
        userid= request.POST.get('userid')
        firstname = request.POST.get('firstname')
        lastname = request.POST.get('lastname')
        password = request.POST.get('password')
        email = request.POST.get('email')
        mblenum = request.POST.get('mblenum')

        gender = request.POST.get('gender')

        RegisterModel.objects.create(userid=userid,firstname=firstname,lastname=lastname,password=password,email=email,
                                     mblenum=mblenum,gender=gender)

    return render(request, 'register.html')


def mydetails(request):
    names = request.session['names']
    ted = RegisterModel.objects.get(id=names)

    return render(request, 'mydetails.html',{'obje':ted})


def value(request):
    Vobj = brainstrokeModel.objects.order_by('-id')[:1]
    return render(request,'value.html',{'objects':Vobj})




def brainstroke(request):

    if request.method == "POST":
        gender = request.POST.get('gender')
        age = int(request.POST.get('age'))
        hypertension = int(request.POST.get('hypertension'))
        disease = int(request.POST.get('disease'))
        married = request.POST.get('married')
        work = request.POST.get('work')
        residence = request.POST.get('residence')
        glucose = float(request.POST.get('glucose'))
        bmi = float(request.POST.get('bmi'))
        smoking = request.POST.get('smoking')

        # gender
        if (gender == "Male"):
            gender_male = 1
            gender_other = 0
        elif (gender == "Other"):
            gender_male = 0
            gender_other = 1
        else:
            gender_male = 0
            gender_other = 0

        # married
        if (married == "Yes"):
            married_yes = 1
        else:
            married_yes = 0

        # work  type
        if (work == 'Self-employed'):
            work_type_Never_worked = 0
            work_type_Private = 0
            work_type_Self_employed = 1
            work_type_children = 0
        elif (work == 'Private'):
            work_type_Never_worked = 0
            work_type_Private = 1
            work_type_Self_employed = 0
            work_type_children = 0
        elif (work == "children"):
            work_type_Never_worked = 0
            work_type_Private = 0
            work_type_Self_employed = 0
            work_type_children = 1
        elif (work == "Never_worked"):
            work_type_Never_worked = 1
            work_type_Private = 0
            work_type_Self_employed = 0
            work_type_children = 0
        else:
            work_type_Never_worked = 0
            work_type_Private = 0
            work_type_Self_employed = 0
            work_type_children = 0

        # residence type
        if (residence == "Urban"):
            Residence_type_Urban = 1
        else:
            Residence_type_Urban = 0

        # smoking sttaus
        if (smoking == 'formerly smoked'):
            smoking_status_formerly_smoked = 1
            smoking_status_never_smoked = 0
            smoking_status_smokes = 0
        elif (smoking == 'smokes'):
            smoking_status_formerly_smoked = 0
            smoking_status_never_smoked = 0
            smoking_status_smokes = 1
        elif (smoking == "never smoked"):
            smoking_status_formerly_smoked = 0
            smoking_status_never_smoked = 1
            smoking_status_smokes = 0
        else:
            smoking_status_formerly_smoked = 0
            smoking_status_never_smoked = 0
            smoking_status_smokes = 0

        feature = scaler.fit_transform(
            [[age, hypertension, disease, glucose, bmi, gender_male, gender_other, married_yes,
              work_type_Never_worked, work_type_Private, work_type_Self_employed, work_type_children,
              Residence_type_Urban, smoking_status_formerly_smoked, smoking_status_never_smoked,
              smoking_status_smokes]])

        prediction = model.predict(feature)[0]
        # print(prediction)
        #
        if age>60 and glucose>220 and bmi>30 and disease==1:
            val= "YES"
        else:
            val="NO"
        if prediction == 0:
            prediction = "NO"
        else:
            prediction = "YES"

        brainstrokeModel.objects.create(gender1=gender, age=age, hypertension=hypertension,
                                        heart_disease=disease, ever_married=married,
                                        work_type=work, Residence_type=residence,
                                        avg_glucose_level=glucose, bmi=bmi
                                        , smoking_status=smoking, stroke=val)
        return redirect('value')




    return render(request,"brainstroke.html")





