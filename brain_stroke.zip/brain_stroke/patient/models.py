from django.db import models

# Create your models here.

class RegisterModel(models.Model):
    firstname=models.CharField(max_length=300)
    lastname=models.CharField(max_length=200)
    userid=models.CharField(max_length=200)
    password=models.CharField(max_length=200)
    mblenum=models.BigIntegerField()
    email=models.EmailField(max_length=400)
    gender=models.CharField(max_length=200)


class brainstrokeModel(models.Model):
    gender1=models.CharField(max_length=300)
    age=models.CharField(max_length=200)
    hypertension=models.CharField(max_length=200)
    heart_disease=models.CharField(max_length=200)
    ever_married=models.CharField(max_length=200)
    work_type=models.CharField(max_length=200)
    Residence_type=models.CharField(max_length=200)
    avg_glucose_level=models.CharField(max_length=200)
    bmi=models.CharField(max_length=200)
    smoking_status=models.CharField(max_length=200)
    stroke=models.CharField(max_length=200)

