from django.db import models

# Create your models here.

class adminsModel(models.Model):
    adname=models.CharField(max_length=300)
    adem=models.EmailField(max_length=200)
    admob=models.BigIntegerField()
    adpass=models.CharField(max_length=200)


class lrmodel(models.Model):
    lraccuracy=models.CharField(max_length=300)
    lrprecision=models.CharField(max_length=200)
    lrrecall=models.CharField(max_length=200)
    lrf1=models.CharField(max_length=200)


class dtmodel(models.Model):
    dtaccuracy=models.CharField(max_length=300)
    dtprecision=models.CharField(max_length=200)
    dtrecall=models.CharField(max_length=200)
    dtf1=models.CharField(max_length=200)

class rfmodel(models.Model):
    rfaccuracy=models.CharField(max_length=300)
    rfprecision=models.CharField(max_length=200)
    rfrecall=models.CharField(max_length=200)
    rff1=models.CharField(max_length=200)

class xgbmodel(models.Model):
    xgbaccuracy=models.CharField(max_length=300)
    xgbprecision=models.CharField(max_length=200)
    xgbrecall=models.CharField(max_length=200)
    xgbf1=models.CharField(max_length=200)


