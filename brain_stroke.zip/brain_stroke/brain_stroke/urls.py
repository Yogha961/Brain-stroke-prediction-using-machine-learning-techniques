"""brain_stroke URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.11/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url
from django.contrib import admin

from patient import views as patient_view

from doctor import views as doctor_view

urlpatterns = [
    url(r'^admin/', admin.site.urls),

    url(r'^$', patient_view.home, name="home"),
    url(r'index', patient_view.index, name="index"),
    url(r'^register/$', patient_view.register, name="register"),
    url(r'^mydetails/$', patient_view.mydetails, name="mydetails"),
    url(r'^brainstroke/$', patient_view.brainstroke, name="brainstroke"),
    url(r'^value/$', patient_view.value, name="value"),


    url(r'^admin_login/$', doctor_view.admin_login, name="admin_login"),
    url(r'^admins_register/$', doctor_view.admins_register, name="admins_register"),
    url(r'^userdetails/$', doctor_view.userdetails, name="userdetails"),
    url(r'^bsdetails/$', doctor_view.bsdetails, name="bsdetails"),
    url(r'^correlation/$', doctor_view.correlation, name="correlation"),
    url(r'^lr/$', doctor_view.lr, name="lr"),
    url(r'^dt/$', doctor_view.dt, name="dt"),
    url(r'^rf/$', doctor_view.rf, name="rf"),
    url(r'^xgb/$', doctor_view.xgb, name="xgb"),
    url(r'^alg/$', doctor_view.alg, name="alg"),
]
