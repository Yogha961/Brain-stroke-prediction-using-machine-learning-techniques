-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 28, 2022 at 12:48 PM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `brain_stroke`
--
CREATE DATABASE IF NOT EXISTS `brain_stroke` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `brain_stroke`;

-- --------------------------------------------------------

--
-- Table structure for table `auth_group`
--

CREATE TABLE IF NOT EXISTS `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `auth_group_permissions`
--

CREATE TABLE IF NOT EXISTS `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `auth_permission`
--

CREATE TABLE IF NOT EXISTS `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=40 ;

--
-- Dumping data for table `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can add permission', 2, 'add_permission'),
(5, 'Can change permission', 2, 'change_permission'),
(6, 'Can delete permission', 2, 'delete_permission'),
(7, 'Can add group', 3, 'add_group'),
(8, 'Can change group', 3, 'change_group'),
(9, 'Can delete group', 3, 'delete_group'),
(10, 'Can add user', 4, 'add_user'),
(11, 'Can change user', 4, 'change_user'),
(12, 'Can delete user', 4, 'delete_user'),
(13, 'Can add content type', 5, 'add_contenttype'),
(14, 'Can change content type', 5, 'change_contenttype'),
(15, 'Can delete content type', 5, 'delete_contenttype'),
(16, 'Can add session', 6, 'add_session'),
(17, 'Can change session', 6, 'change_session'),
(18, 'Can delete session', 6, 'delete_session'),
(19, 'Can add admins model', 7, 'add_adminsmodel'),
(20, 'Can change admins model', 7, 'change_adminsmodel'),
(21, 'Can delete admins model', 7, 'delete_adminsmodel'),
(22, 'Can add register model', 8, 'add_registermodel'),
(23, 'Can change register model', 8, 'change_registermodel'),
(24, 'Can delete register model', 8, 'delete_registermodel'),
(25, 'Can add brainstroke model', 9, 'add_brainstrokemodel'),
(26, 'Can change brainstroke model', 9, 'change_brainstrokemodel'),
(27, 'Can delete brainstroke model', 9, 'delete_brainstrokemodel'),
(28, 'Can add dtmodel', 10, 'add_dtmodel'),
(29, 'Can change dtmodel', 10, 'change_dtmodel'),
(30, 'Can delete dtmodel', 10, 'delete_dtmodel'),
(31, 'Can add lrmodel', 11, 'add_lrmodel'),
(32, 'Can change lrmodel', 11, 'change_lrmodel'),
(33, 'Can delete lrmodel', 11, 'delete_lrmodel'),
(34, 'Can add rfmodel', 12, 'add_rfmodel'),
(35, 'Can change rfmodel', 12, 'change_rfmodel'),
(36, 'Can delete rfmodel', 12, 'delete_rfmodel'),
(37, 'Can add xgbmodel', 13, 'add_xgbmodel'),
(38, 'Can change xgbmodel', 13, 'change_xgbmodel'),
(39, 'Can delete xgbmodel', 13, 'delete_xgbmodel');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user`
--

CREATE TABLE IF NOT EXISTS `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_groups`
--

CREATE TABLE IF NOT EXISTS `auth_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_user_permissions`
--

CREATE TABLE IF NOT EXISTS `auth_user_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `django_admin_log`
--

CREATE TABLE IF NOT EXISTS `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `django_content_type`
--

CREATE TABLE IF NOT EXISTS `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1, 'admin', 'logentry'),
(3, 'auth', 'group'),
(2, 'auth', 'permission'),
(4, 'auth', 'user'),
(5, 'contenttypes', 'contenttype'),
(7, 'doctor', 'adminsmodel'),
(10, 'doctor', 'dtmodel'),
(11, 'doctor', 'lrmodel'),
(12, 'doctor', 'rfmodel'),
(13, 'doctor', 'xgbmodel'),
(9, 'patient', 'brainstrokemodel'),
(8, 'patient', 'registermodel'),
(6, 'sessions', 'session');

-- --------------------------------------------------------

--
-- Table structure for table `django_migrations`
--

CREATE TABLE IF NOT EXISTS `django_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `django_migrations`
--

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'contenttypes', '0001_initial', '2022-03-23 11:03:17.471604'),
(2, 'auth', '0001_initial', '2022-03-23 11:03:49.960286'),
(3, 'admin', '0001_initial', '2022-03-23 11:03:59.399308'),
(4, 'admin', '0002_logentry_remove_auto_add', '2022-03-23 11:03:59.459302'),
(5, 'contenttypes', '0002_remove_content_type_name', '2022-03-23 11:04:01.479091'),
(6, 'auth', '0002_alter_permission_name_max_length', '2022-03-23 11:04:02.468990'),
(7, 'auth', '0003_alter_user_email_max_length', '2022-03-23 11:04:03.388900'),
(8, 'auth', '0004_alter_user_username_opts', '2022-03-23 11:04:03.448891'),
(9, 'auth', '0005_alter_user_last_login_null', '2022-03-23 11:04:04.218808'),
(10, 'auth', '0006_require_contenttypes_0002', '2022-03-23 11:04:04.258804'),
(11, 'auth', '0007_alter_validators_add_error_messages', '2022-03-23 11:04:04.328796'),
(12, 'auth', '0008_alter_user_username_max_length', '2022-03-23 11:04:05.218710'),
(13, 'doctor', '0001_initial', '2022-03-23 11:04:05.788643'),
(14, 'patient', '0001_initial', '2022-03-23 11:04:06.598559'),
(15, 'sessions', '0001_initial', '2022-03-23 11:04:10.558149'),
(16, 'patient', '0002_brainstrokemodel', '2022-03-24 05:09:11.195978'),
(17, 'doctor', '0002_dtmodel_lrmodel_rfmodel_xgbmodel', '2022-03-25 15:02:48.567991');

-- --------------------------------------------------------

--
-- Table structure for table `django_session`
--

CREATE TABLE IF NOT EXISTS `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `django_session`
--

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('9nlq1q60m3ongqelz2rsa1btdm6adqdf', 'ODc5Yzk2M2QxYWE4ZGJhMzEwYzk5YWM2MmYyMWYxNWIyODQ2NDlhNTp7Im5hbWVzIjoxLCJhZG1pbnMiOjF9', '2022-04-11 06:08:01.463748');

-- --------------------------------------------------------

--
-- Table structure for table `doctor_adminsmodel`
--

CREATE TABLE IF NOT EXISTS `doctor_adminsmodel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adname` varchar(300) NOT NULL,
  `adem` varchar(200) NOT NULL,
  `admob` bigint(20) NOT NULL,
  `adpass` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `doctor_adminsmodel`
--

INSERT INTO `doctor_adminsmodel` (`id`, `adname`, `adem`, `admob`, `adpass`) VALUES
(1, 'doctor', 'doctor@gmail.com', 6577653423, 'doctor');

-- --------------------------------------------------------

--
-- Table structure for table `doctor_dtmodel`
--

CREATE TABLE IF NOT EXISTS `doctor_dtmodel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dtaccuracy` varchar(300) NOT NULL,
  `dtprecision` varchar(200) NOT NULL,
  `dtrecall` varchar(200) NOT NULL,
  `dtf1` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `doctor_dtmodel`
--

INSERT INTO `doctor_dtmodel` (`id`, `dtaccuracy`, `dtprecision`, `dtrecall`, `dtf1`) VALUES
(1, '0.93', '0.91', '0.95', '0.93'),
(2, '0.93', '0.92', '0.94', '0.93'),
(3, '0.92', '0.91', '0.93', '0.92'),
(4, '0.93', '0.91', '0.94', '0.93'),
(5, '0.91', '0.90', '0.92', '0.91'),
(6, '0.92', '0.91', '0.94', '0.92'),
(7, '0.93', '0.92', '0.94', '0.93'),
(8, '0.92', '0.92', '0.94', '0.93'),
(9, '0.91', '0.90', '0.93', '0.91');

-- --------------------------------------------------------

--
-- Table structure for table `doctor_lrmodel`
--

CREATE TABLE IF NOT EXISTS `doctor_lrmodel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lraccuracy` varchar(300) NOT NULL,
  `lrprecision` varchar(200) NOT NULL,
  `lrrecall` varchar(200) NOT NULL,
  `lrf1` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `doctor_lrmodel`
--

INSERT INTO `doctor_lrmodel` (`id`, `lraccuracy`, `lrprecision`, `lrrecall`, `lrf1`) VALUES
(1, '0.79', '0.79', '0.80', '0.80'),
(2, '0.82', '0.81', '0.84', '0.82'),
(3, '0.82', '0.81', '0.84', '0.82'),
(4, '0.81', '0.80', '0.82', '0.81'),
(5, '0.81', '0.80', '0.83', '0.81'),
(6, '0.82', '0.81', '0.83', '0.82'),
(7, '0.81', '0.80', '0.82', '0.81'),
(8, '0.81', '0.81', '0.82', '0.81'),
(9, '0.80', '0.80', '0.80', '0.80');

-- --------------------------------------------------------

--
-- Table structure for table `doctor_rfmodel`
--

CREATE TABLE IF NOT EXISTS `doctor_rfmodel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rfaccuracy` varchar(300) NOT NULL,
  `rfprecision` varchar(200) NOT NULL,
  `rfrecall` varchar(200) NOT NULL,
  `rff1` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `doctor_rfmodel`
--

INSERT INTO `doctor_rfmodel` (`id`, `rfaccuracy`, `rfprecision`, `rfrecall`, `rff1`) VALUES
(1, '0.95', '0.94', '0.95', '0.95'),
(2, '0.95', '0.94', '0.97', '0.96'),
(3, '0.94', '0.94', '0.95', '0.94'),
(4, '0.94', '0.94', '0.95', '0.95');

-- --------------------------------------------------------

--
-- Table structure for table `doctor_xgbmodel`
--

CREATE TABLE IF NOT EXISTS `doctor_xgbmodel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `xgbaccuracy` varchar(300) NOT NULL,
  `xgbprecision` varchar(200) NOT NULL,
  `xgbrecall` varchar(200) NOT NULL,
  `xgbf1` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `doctor_xgbmodel`
--

INSERT INTO `doctor_xgbmodel` (`id`, `xgbaccuracy`, `xgbprecision`, `xgbrecall`, `xgbf1`) VALUES
(1, '0.96', '0.96', '0.97', '0.96'),
(2, '0.96', '0.95', '0.98', '0.96'),
(3, '0.96', '0.96', '0.96', '0.96'),
(4, '0.96', '0.95', '0.97', '0.96');

-- --------------------------------------------------------

--
-- Table structure for table `patient_brainstrokemodel`
--

CREATE TABLE IF NOT EXISTS `patient_brainstrokemodel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gender1` varchar(300) NOT NULL,
  `age` varchar(200) NOT NULL,
  `hypertension` varchar(200) NOT NULL,
  `heart_disease` varchar(200) NOT NULL,
  `ever_married` varchar(200) NOT NULL,
  `work_type` varchar(200) NOT NULL,
  `Residence_type` varchar(200) NOT NULL,
  `avg_glucose_level` varchar(200) NOT NULL,
  `bmi` varchar(200) NOT NULL,
  `smoking_status` varchar(200) NOT NULL,
  `stroke` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `patient_brainstrokemodel`
--

INSERT INTO `patient_brainstrokemodel` (`id`, `gender1`, `age`, `hypertension`, `heart_disease`, `ever_married`, `work_type`, `Residence_type`, `avg_glucose_level`, `bmi`, `smoking_status`, `stroke`) VALUES
(1, 'Male', '34', '1', '0', 'No', 'Govt_job', 'Urban', '202.21', '22.8', 'smokes', 'NO'),
(2, 'Male', '67', '0', '1', 'Yes', 'Private', 'Urban', '228.69', '36.6', 'formerly smoked', 'NO'),
(3, 'Female', '52', '0', '0', 'Yes', 'Private', 'Urban', '82.24', '54.7', 'formerly smoked', 'NO'),
(4, 'Male', '65', '0', '1', 'Yes', 'Private', 'Urban', '340.4', '36.6', 'never smoked', 'YES'),
(5, 'Female', '87', '1', '0', 'Yes', 'Govt_job', 'Urban', '340.4', '15.6', 'never smoked', 'NO'),
(6, 'Male', '65', '0', '1', 'Yes', 'Private', 'Urban', '324.6', '34.1', 'formerly smoked', 'YES'),
(7, 'Female', '87', '1', '1', 'Yes', 'Private', 'Urban', '340.4', '34.1', 'formerly smoked', 'YES'),
(8, 'Female', '43', '1', '0', 'Yes', 'Private', 'Urban', '120.3', '15.6', 'never smoked', 'NO'),
(9, 'Female', '76', '0', '1', 'Yes', 'Govt_job', 'Rural', '340.4', '36.6', 'formerly smoked', 'YES');

-- --------------------------------------------------------

--
-- Table structure for table `patient_registermodel`
--

CREATE TABLE IF NOT EXISTS `patient_registermodel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(300) NOT NULL,
  `lastname` varchar(200) NOT NULL,
  `userid` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `mblenum` bigint(20) NOT NULL,
  `email` varchar(400) NOT NULL,
  `gender` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `patient_registermodel`
--

INSERT INTO `patient_registermodel` (`id`, `firstname`, `lastname`, `userid`, `password`, `mblenum`, `email`, `gender`) VALUES
(1, 'new', 'one', 'new', 'new', 9876876656, 'new@gmail.com', 'male');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`);

--
-- Constraints for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`);

--
-- Constraints for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  ADD CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`);

--
-- Constraints for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  ADD CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
